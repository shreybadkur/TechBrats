import csv
import boto3

with open('credentials.csv','r') as input:
    next(input)
    reader = csv.reader(input)
    for line in reader:
        access_key_id = line[2]
        secret_access_key = line[3]

client = boto3.client('rekognition', aws_access_key_id = access_key_id, aws_secret_access_key = secret_access_key,  region_name='ap-south-1' )

response = client.compare_faces(SourceImage = 
                                {
                                    'S3Object': 
                                    {
                                        'Bucket': 'humanrecog',
                                        'Name': '1.jpg'
                                    }
                                },
                                TargetImage =
                                {
                                    'S3Object': 
                                    {
                                        'Bucket': 'humanrecog',
                                        'Name': '2.jpg'
                                    }
                                }
                                )
for key, value in response.items():
    if key in ('FaceMatches'):
        print(key)
        for att in value:
            print(att)