import java.awt.*;
import java.awt.event.*;
import java.io.File;

import javax.swing.*;

import jdk.tools.jimage.resources.jimage;

import java.sql.*;

public class Register extends JFrame{

	public JPanel mainPanel;
	JLabel name,email,id,authorization,title,photo;
	JTextField n1,e1,i1,a1;
	JButton submit,cancel, uploadimg;
	JRadioButton auth,unauth;
	JFileChooser jfc;
	jimage 
	public Register() {
		this.setVisible(true);
		this.setSize(getMaximumSize());
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		auth = new JRadioButton("Authorized");
		unauth = new JRadioButton("Unauthorized");
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(auth);bg.add(unauth);
		
		mainPanel = new JPanel();
		name = new JLabel("Name");
		email = new JLabel("Email ID");
		id = new JLabel("Entry ID");
		authorization = new JLabel("Autorization");
		title = new JLabel("SMART INDIA HACKATHON");
		photo = new JLabel();
		
		
		n1 = new JTextField(20);
		e1 = new JTextField(20);
		i1 = new JTextField(20);
		a1 = new JTextField(20);
		
		uploadimg = new JButton("Upload Photo");
		submit = new JButton("Submit");
		cancel = new JButton("Clear");
		
		jfc = new JFileChooser();
		
		SpringLayout sl = new SpringLayout();
		mainPanel.setLayout(sl);
		
		mainPanel.add(title);
		mainPanel.add(name);
		mainPanel.add(n1);
		mainPanel.add(email);
		mainPanel.add(e1);
		mainPanel.add(id);
		mainPanel.add(i1);
		mainPanel.add(auth);
		mainPanel.add(unauth);
		mainPanel.add(submit);
		mainPanel.add(cancel);
		mainPanel.add(uploadimg);
		
		title.setFont(new Font("Arial Black", Font.BOLD, 40));
		title.setForeground(Color.GREEN);
		name.setFont(new Font("Arial", Font.PLAIN, 20));
		email.setFont(new Font("Arial", Font.PLAIN, 20));
		id.setFont(new Font("Arial", Font.PLAIN, 20));
		authorization.setFont(new Font("Arial", Font.PLAIN, 20));
		auth.setFont(new Font("Arial", Font.PLAIN, 20));
		unauth.setFont(new Font("Arial", Font.PLAIN, 20));
		
		sl.putConstraint(SpringLayout.WEST, name, 100, SpringLayout.WEST, mainPanel);
		sl.putConstraint(SpringLayout.NORTH, name, 200, SpringLayout.NORTH, mainPanel);
		sl.putConstraint(SpringLayout.WEST, title, 500, SpringLayout.WEST, mainPanel);
		sl.putConstraint(SpringLayout.NORTH, title, 50, SpringLayout.NORTH, mainPanel);
		sl.putConstraint(SpringLayout.WEST, n1, 200, SpringLayout.WEST, name);
		sl.putConstraint(SpringLayout.NORTH, n1, 200, SpringLayout.NORTH, mainPanel);
		sl.putConstraint(SpringLayout.WEST, email, 100, SpringLayout.WEST, mainPanel);
		sl.putConstraint(SpringLayout.NORTH, email, 300, SpringLayout.NORTH, mainPanel);
		sl.putConstraint(SpringLayout.WEST, e1, 200, SpringLayout.WEST, email);
		sl.putConstraint(SpringLayout.NORTH, e1, 300, SpringLayout.NORTH, mainPanel);
		sl.putConstraint(SpringLayout.WEST, id, 100, SpringLayout.WEST, mainPanel);
		sl.putConstraint(SpringLayout.NORTH, id, 400, SpringLayout.NORTH, mainPanel);
		sl.putConstraint(SpringLayout.WEST, i1, 200, SpringLayout.WEST, id);
		sl.putConstraint(SpringLayout.NORTH, i1, 400, SpringLayout.NORTH, mainPanel);
		sl.putConstraint(SpringLayout.WEST, auth, 100, SpringLayout.WEST, mainPanel);
		sl.putConstraint(SpringLayout.NORTH, auth, 500, SpringLayout.NORTH, mainPanel);
		sl.putConstraint(SpringLayout.WEST, unauth, 200, SpringLayout.WEST, auth);
		sl.putConstraint(SpringLayout.NORTH, unauth, 500, SpringLayout.NORTH, mainPanel);
		sl.putConstraint(SpringLayout.WEST, submit, 700, SpringLayout.WEST, mainPanel);
		sl.putConstraint(SpringLayout.NORTH, submit, 700, SpringLayout.NORTH, mainPanel);
		sl.putConstraint(SpringLayout.WEST, cancel, 800, SpringLayout.WEST, mainPanel);
		sl.putConstraint(SpringLayout.NORTH, cancel, 700, SpringLayout.NORTH, mainPanel);
		sl.putConstraint(SpringLayout.WEST, uploadimg, 100, SpringLayout.WEST, mainPanel);
		sl.putConstraint(SpringLayout.NORTH, uploadimg, 600, SpringLayout.NORTH, mainPanel);
		
		
	
		getContentPane().add(mainPanel);
		
		submit.addActionListener(e->actionS(e));
		cancel.addActionListener(e->actionC(e));
		uploadimg.addActionListener(e->actionU(e));
	}
	public void actionC(ActionEvent e) {
		// TODO Auto-generated method stub
		n1.setText("");
		a1.setText("");
		e1.setText("");
		i1.setText("");
		
	}
	public void actionS(ActionEvent e) {
		String a ="" ;
		
		if(auth.isSelected())
			a = "Authorized";
		else if(unauth.isSelected())
			a = "Unauthorized";
		else {
			JOptionPane.showMessageDialog(null, "Select Authorization");
		}
			
		try {
			if(n1.getText().length()!=0 && e1.getText().length()!=0
					&& i1.getText().length()!=0 && a.length()!=0) {
		Class.forName("org.postgresql.Driver");
		Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres",
									"postgres","avengers");
		String sql = "insert into maindata(name,email,id,auth,height)"
				+ "values('"+n1.getText().toString()+"','"+e1.getText().toString()+"','"
				+ i1.getText().toString()+"','"+a+"','"
				+"')";
		Statement stmt = conn.createStatement();
		stmt.execute(sql);
		stmt.close();
		conn.close();
		
		JOptionPane.showMessageDialog(null, "Data Submitted");
			}
			else {
				JOptionPane.showMessageDialog(null, "Fill all the parameters");
			}
		}
		catch(Exception ex) {
			JOptionPane.showMessageDialog(null, "Database connection Error "+ex.toString());
		}
	}
	public void actionU(ActionEvent e)
	{
		jfc.showOpenDialog(null);
		
	
		
	}
	
	public static void main(String args[]) {
		new Register();
	}
}
