import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;


public class Home extends JFrame implements Runnable {

	int i=1;
	public JPanel jp;
	JLabel video,name,n1,id,id1,auth,auth1,photo,title,date,d1;
	Thread th1;
	JButton register,search,edit,dailyLog,logout,fullscreen;
	
	public Home(){
		this.setVisible(true);
		this.setSize(400,400);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jp = new JPanel();
		
		video = new JLabel();
		name = new JLabel("Name : ");
		n1 = new JLabel("");
		id = new JLabel("ID : ");
		id1 = new JLabel("");
		auth = new JLabel("Authorization : ");
		auth1 = new JLabel();
		photo = new JLabel();
		title = new JLabel("Human Recognition Security Alert System");
		date = new JLabel("Date and Time : ");
		d1 = new JLabel();
		
		register = new JButton("New Registeration");
		search= new JButton("Search Person");
		dailyLog = new JButton("Daily Record");
		edit = new JButton("Edit Information");
		logout = new JButton("Logout");
		fullscreen = new JButton("Full Screen Mode");
		
		
		
		title.setFont(new Font("Comic Sans MS", Font.BOLD, 40));
		title.setForeground(Color.magenta);
		name.setFont(new Font("Arial", Font.PLAIN, 20));
		id.setFont(new Font("Arial", Font.PLAIN, 20));
		auth.setFont(new Font("Arial", Font.PLAIN, 20));
		n1.setFont(new Font("Arial", Font.PLAIN, 20));
		id1.setFont(new Font("Arial", Font.PLAIN, 20));
		date.setFont(new Font("Arial", Font.PLAIN, 20));
		d1.setFont(new Font("Arial", Font.PLAIN, 20));
		
		checkAuthorization(true);
		
		
		
		ImageIcon ico3 = new ImageIcon("d:\\Log\\9.jpg");
		Image img1 = ico3.getImage();
		Image newimg1 = img1.getScaledInstance(500, 500, Image.SCALE_SMOOTH);
		ImageIcon ico4 = new ImageIcon(newimg1);
		photo.setIcon(ico4);
		
		th1 = new Thread(this);
		th1.start();
		SpringLayout sl = new SpringLayout();
		jp.setLayout(sl);
		sl.putConstraint(SpringLayout.WEST, video, 25, SpringLayout.WEST, jp);
		sl.putConstraint(SpringLayout.NORTH, video, 80, SpringLayout.NORTH, jp);
		sl.putConstraint(SpringLayout.WEST, title, 325, SpringLayout.WEST, jp);
		sl.putConstraint(SpringLayout.NORTH, title, 5, SpringLayout.NORTH, jp);
		sl.putConstraint(SpringLayout.WEST, name, 100, SpringLayout.WEST, jp);
		sl.putConstraint(SpringLayout.NORTH, name, 575, SpringLayout.NORTH, jp);
		sl.putConstraint(SpringLayout.WEST, n1, 100, SpringLayout.WEST, name);
		sl.putConstraint(SpringLayout.NORTH, n1, 575, SpringLayout.NORTH, jp);
		sl.putConstraint(SpringLayout.WEST, id, 100, SpringLayout.WEST, jp);
		sl.putConstraint(SpringLayout.NORTH, id, 50, SpringLayout.NORTH, name);
		sl.putConstraint(SpringLayout.WEST, id1, 100, SpringLayout.WEST, id);
		sl.putConstraint(SpringLayout.NORTH, id1, 50, SpringLayout.NORTH, name);
		sl.putConstraint(SpringLayout.WEST, auth, 100, SpringLayout.WEST, jp);
		sl.putConstraint(SpringLayout.NORTH, auth, 50, SpringLayout.NORTH, id);
		sl.putConstraint(SpringLayout.WEST, auth1, 150, SpringLayout.WEST, auth);
		sl.putConstraint(SpringLayout.NORTH, auth1, 50, SpringLayout.NORTH, id);
		sl.putConstraint(SpringLayout.WEST, photo, 1000, SpringLayout.WEST, jp);
		sl.putConstraint(SpringLayout.NORTH, photo, 80, SpringLayout.NORTH, jp);
		sl.putConstraint(SpringLayout.WEST, date, 100, SpringLayout.WEST, jp);
		sl.putConstraint(SpringLayout.NORTH, date, 50, SpringLayout.NORTH, auth);
		sl.putConstraint(SpringLayout.WEST, d1, 150, SpringLayout.WEST, date);
		sl.putConstraint(SpringLayout.NORTH, d1, 50, SpringLayout.NORTH, auth);
		sl.putConstraint(SpringLayout.WEST, register, 900, SpringLayout.WEST, jp);
		sl.putConstraint(SpringLayout.NORTH, register, 700, SpringLayout.NORTH, jp);
		sl.putConstraint(SpringLayout.WEST, search, 150, SpringLayout.WEST, register);
		sl.putConstraint(SpringLayout.NORTH, search, 700, SpringLayout.NORTH, jp);
		sl.putConstraint(SpringLayout.WEST, dailyLog, 130, SpringLayout.WEST, search);
		sl.putConstraint(SpringLayout.NORTH, dailyLog, 700, SpringLayout.NORTH, jp);
		sl.putConstraint(SpringLayout.WEST, edit, 120, SpringLayout.WEST, dailyLog);
		sl.putConstraint(SpringLayout.NORTH, edit, 700, SpringLayout.NORTH, jp);
		sl.putConstraint(SpringLayout.WEST, logout, 130, SpringLayout.WEST, edit);
		sl.putConstraint(SpringLayout.NORTH, logout, 700, SpringLayout.NORTH, jp);
		sl.putConstraint(SpringLayout.WEST, fullscreen, 550, SpringLayout.WEST, video);
		sl.putConstraint(SpringLayout.NORTH, fullscreen, 470, SpringLayout.NORTH,video);
		
		
		jp.add(d1);
		jp.add(date);
		jp.add(photo);
		jp.add(auth1);
		jp.add(id1);
		jp.add(n1);
		jp.add(auth);
		jp.add(id);
		jp.add(name);
		jp.add(video);
		jp.add(title);
		jp.add(register);
		jp.add(search);
		jp.add(dailyLog);
		jp.add(edit);
		jp.add(logout);
		jp.add(fullscreen);
		jp.setBackground(Color.LIGHT_GRAY);
		register.addActionListener(e->actionReg(e));
		
	
		getContentPane().add(jp);	
	}
	
	public void actionReg(ActionEvent e)
	{
		getContentPane().remove(jp);
		Register obj = new Register();
		getContentPane().add(obj.mainPanel);
	}
	public void run() {
		for(;;) {
			try {
				this.setTitle(new java.util.Date().toString());
				d1.setText(new java.util.Date().toString());
				ImageIcon ico = new ImageIcon("d:\\Log\\"+i+".jpg");
				Image img = ico.getImage();
				Image newimg = img.getScaledInstance(700, 460, Image.SCALE_SMOOTH);
				ImageIcon ico1 = new ImageIcon(newimg);
				video.setIcon(ico1);
				i++;
				th1.sleep(1000);
				
			} catch(Exception ex) {
				JOptionPane.showMessageDialog(null, ex.toString());
			}
	}
	}
	public void checkAuthorization(boolean x)
	{
		if(true) {
			auth1.setText("AUTHORIZED");
			auth1.setFont(new Font("Arial", Font.PLAIN, 20));
			auth1.setForeground(Color.green);
		}
		else {
			auth1.setText("UNAUTHORIZED");
			auth1.setFont(new Font("Arial", Font.PLAIN, 20));
			auth1.setForeground(Color.RED);
		}
	}
	public static void main(String args[]) {
		new Home();
	}
	
}
