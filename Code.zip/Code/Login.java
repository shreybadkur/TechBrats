
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;

import com.sun.java.accessibility.util.SwingEventMonitor;
import java.sql.*;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;


public class Login extends JFrame {
	JPanel mainPanel,p1;
	JLabel login,pass,title;
//	JButton exit;
	JButton sign;
	JTextField tf1;
	JPasswordField pf1;
	JLabel image;
	
	public Login()
	{
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600,400);
			
		
		mainPanel = new JPanel();
		p1 = new JPanel();
		//p1.add(img);
		
		
		image = new JLabel();
		
		
		ImageIcon img = new ImageIcon("D:\\BNE\\2.jpeg");
		Image img1 = img.getImage();
		Image newimg = img1.getScaledInstance(1920, 1080, Image.SCALE_SMOOTH);
		ImageIcon ico = new ImageIcon(newimg);
		image.setIcon(ico);
		

		p1.add(image,JPanel.CENTER_ALIGNMENT);
		
		
		
		tf1.addActionListener(e->actiontf(e));
		
		title = new JLabel("Human Recognition Security Alert System");
		login = new JLabel("Login id");
		pass = new JLabel("Password");
		tf1 = new JTextField(20);
		pf1 = new JPasswordField(20);
		sign = new JButton("Submit");
		
		
		title.setFont(new Font("Comic Sans MS", Font.BOLD, 50));
		title.setForeground(Color.white);
		title.setBackground(Color.blue);
		Border border = BorderFactory.createLineBorder(Color.GRAY);
		title.setBorder(border);
		SpringLayout sl1 = new SpringLayout();
		
		login.setFont(new Font("Arial", Font.PLAIN,20));
		pass.setFont(new Font("Arial", Font.PLAIN,20));
		
		Dimension d = new Dimension();
		d.setSize(380,200);
		p1.setPreferredSize(d);
		p1.setLayout(sl1);
		
		//sign.setIcon("D:\\BNE\\abc.jpeg");
		
		
		sl1.putConstraint(SpringLayout.WEST, login, 20, SpringLayout.WEST, p1);
		sl1.putConstraint(SpringLayout.NORTH, login, 20, SpringLayout.NORTH, p1);
		sl1.putConstraint(SpringLayout.WEST, pass, 20, SpringLayout.WEST, p1);
		sl1.putConstraint(SpringLayout.NORTH, pass, 80, SpringLayout.NORTH, p1);
		sl1.putConstraint(SpringLayout.WEST, tf1, 150, SpringLayout.WEST, p1);
		sl1.putConstraint(SpringLayout.NORTH, tf1, 20, SpringLayout.NORTH, p1);
		sl1.putConstraint(SpringLayout.WEST, pf1, 150, SpringLayout.WEST, p1);
		sl1.putConstraint(SpringLayout.NORTH, pf1, 80, SpringLayout.NORTH, p1);
		sl1.putConstraint(SpringLayout.WEST, sign, 150, SpringLayout.WEST, p1);
		sl1.putConstraint(SpringLayout.NORTH, sign, 130, SpringLayout.NORTH, p1);
		sl1.putConstraint(SpringLayout.WEST, image, 200, SpringLayout.WEST, p1);
		sl1.putConstraint(SpringLayout.NORTH, image, 100, SpringLayout.NORTH, p1);
		
		
		SpringLayout sl2 = new SpringLayout();
		mainPanel.setLayout(sl2);
		mainPanel.setBackground(Color.LIGHT_GRAY);
		
		sl2.putConstraint(SpringLayout.WEST, title, 300, SpringLayout.WEST, mainPanel);
		sl2.putConstraint(SpringLayout.NORTH, title, 20, SpringLayout.NORTH, mainPanel);
		sl2.putConstraint(SpringLayout.WEST, p1, 550, SpringLayout.WEST, mainPanel);
		sl2.putConstraint(SpringLayout.NORTH, p1, 300, SpringLayout.NORTH, mainPanel);
		p1.setBorder(BorderFactory.createTitledBorder("Login Panel"));
		
		sign.addActionListener(e->actionB1(e));
		
		
		p1.add(sign);
		p1.add(login);
		p1.add(pass);
		p1.add(tf1);
		p1.add(pf1);
		mainPanel.add(title);
		mainPanel.add(p1);
		mainPanel.add(image);
		
		
		//setContentPane(new JLabel(new ImageIcon("D:\\BNE\\1.jpg")));
		getContentPane().add(mainPanel);
		
		
	}
	public void actiontf(ActionEvent e) {
		JOptionPane.showMessageDialog(null, "h1");
	}
	
	
	public void actionB1(ActionEvent e)
	{
		String loginid = tf1.getText().toString();
		String password = pf1.getText().toString();
		
		try {
			Class.forName("org.postgresql.Driver");
			Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres",
					"postgres","avengers");
			String sql = "select * from logindata";
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
			//JOptionPane.showMessageDialog(null, rs.getString(1));
			
			if(rs.getString(1).equals(loginid) && rs.getString(2).equals(password))
			{
				JOptionPane.showMessageDialog(null, "Correct login id and password");
				getContentPane().remove(mainPanel);
				Home obj = new Home();
				getContentPane().add(obj.jp);
				
			}
			
		}catch(Exception ex) {
			JOptionPane.showMessageDialog(null, ex);			
		}
	}
	
	public void actionE(ActionEvent e) {
		System.exit(0);
	}
	
	
	public static void main(String args[]) {
		new Login();
	}
}

		